#include "TP4.h"
int main()
{
    int exo;
    printf("Saisisir un numéro d'exercice :");
    scanf(" %d", &exo);
    switch (exo)
    {
        case 1: exo1();
            break;
        case 2: exo2();
            break;
        default : printf("Ce numéro d'exercice n'existe pas.\n");
    }
    return 0;
}