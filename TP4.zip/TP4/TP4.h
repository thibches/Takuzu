//
// Created by chesn on 18/02/2022.
//

#ifndef LAB1_TP4_H
#define LAB1_TP4_H
#include <stdio.h>
void exo1();
void exo2();

// Insérer les autres prototypes ici
#endif //LAB1_TP4_H
